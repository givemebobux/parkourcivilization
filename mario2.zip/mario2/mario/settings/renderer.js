PlayMarioJas.PlayMarioJas.settings.renderer = {
    "groupNames": ["Text", "Character", "Solid", "Scenery"],
    "spriteCacheCutoff": 2048
};
