PlayMarioJas.PlayMarioJas.settings.quadrants = {
    "numRows": 5,
    "numCols": 6,
    "tolerance": PlayMarioJas.PlayMarioJas.unitsize / 2,
    "groupNames": ["Solid", "Character", "Scenery", "Text"],
    "keyGroupName": "groupType"
};
