// workaround to detect whether a 404 or No Internet.
// btw you are offline buddy :)