// your network connection is working and you are online.
window.online = navigator.onLine;